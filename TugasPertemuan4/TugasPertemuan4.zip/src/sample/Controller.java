package sample;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import sample.DAO.TeamDAO;
import sample.DAO.UserDAO;
import sample.entity.Team;
import sample.entity.User;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    @FXML
    private TextField txtNRP;
    @FXML
    private TextField txtNama;
    @FXML
    private ComboBox<Team> comboTeam;
    @FXML
    private TableView<User> tableUser;
    @FXML
    private TableColumn<User, String> nrp;
    @FXML
    private TableColumn<User, String> nama;
    @FXML
    private TableColumn<User, String> team;

    private ObservableList<User> users;
    private ObservableList<Team> teams;


    @Override
    public void initialize(URL location, ResourceBundle resources) {

        UserDAO userDAO = new UserDAO();
        TeamDAO teamDAO = new TeamDAO();
        teams = (ObservableList<Team>) teamDAO.showData();
        comboTeam.setItems(teams);
        users =userDAO.showData();
            tableUser.setItems(users);
            nrp.setCellValueFactory(data->new SimpleStringProperty(String.valueOf(data.getValue().getId())));
            nama.setCellValueFactory(data->new SimpleStringProperty(data.getValue().getNama()));
            team.setCellValueFactory(data->new SimpleStringProperty(data.getValue().getTeam().getName()));



    }

    public void addData(ActionEvent actionEvent) {
        User user =new User();
        user.setId(Integer.valueOf(txtNRP.getText()));
        user.setNama(txtNama.getText());
        user.setTeam(comboTeam.getValue());
        UserDAO userDAO = new UserDAO();
        userDAO.addData(user);
        users.clear();
        users.addAll(userDAO.showData());
        tableUser.refresh();


    }

    public void refresh(ActionEvent actionEvent) {
        tableUser.refresh();
    }
}
